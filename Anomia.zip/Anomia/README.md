#[ModKit Wiki](../../wiki)
# How to get started with KTANE Modding

If you would like to learn how to develop mods in video form, refer to Royal_Flu$h's tutorial series:
https://www.youtube.com/playlist?list=PLDHjUZseb2dn07p0Hh35iYJt-pDtWSgJ0

For videos about things Royal's tutorial does not cover, look here:
https://www.youtube.com/playlist?list=PL-1P5EmkkFxrwWW6z0uZ5nBdRImsReOQ0

Basic setup for first-time users:
- Download this repo (Clone or Download) > (Download ZIP)
- Download Unity 2017.4.22f1
  Link: https://unity3d.com/unity/qa/lts-releases?version=2017.4&page=2
- Download an IDE
  - Visual Studio Link: https://visualstudio.microsoft.com/
  - Visual Studio Code Link: https://code.visualstudio.com/
  - Atom Link: https://atom.io/
  - Notepad++ (Not recommended as an IDE but is still useful) Link: https://notepad-plus-plus.org/