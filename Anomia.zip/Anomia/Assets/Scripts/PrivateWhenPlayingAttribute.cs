﻿using UnityEngine;
public class PrivateWhenPlayingAttribute : PropertyAttribute { }
